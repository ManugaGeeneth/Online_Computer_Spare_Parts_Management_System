package model;

public class order {

	 String cpu;
     String vcard;  // Video Card
     String mem;    // Memory
     String mboard; // Motherboard
     String cool;   // CPU Cooler
     String ssd;    // Storage
     String email;
     
	public String getCpu() {
		return cpu;
	}
	public void setCpu(String cpu) {
		this.cpu = cpu;
	}
	public String getVcard() {
		return vcard;
	}
	public void setVcard(String vcard) {
		this.vcard = vcard;
	}
	public String getMem() {
		return mem;
	}
	public void setMem(String mem) {
		this.mem = mem;
	}
	public String getMboard() {
		return mboard;
	}
	public void setMboard(String mboard) {
		this.mboard = mboard;
	}
	public String getCool() {
		return cool;
	}
	public void setCool(String cool) {
		this.cool = cool;
	}
	public String getSsd() {
		return ssd;
	}
	public void setSsd(String ssd) {
		this.ssd = ssd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
     
     
}
