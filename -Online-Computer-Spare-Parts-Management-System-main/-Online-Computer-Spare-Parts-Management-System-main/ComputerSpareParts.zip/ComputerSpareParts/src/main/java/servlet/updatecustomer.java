package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.order;
import services.orderservice;

@WebServlet("/updatecustomer")
public class updatecustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updatecustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		order cus=new order(); 
		 cus.setCpu(request.getParameter("cpu"));
	        cus.setVcard(request.getParameter("vcard"));
	        cus.setMem(request.getParameter("mem"));
	        cus.setMboard(request.getParameter("mboard"));
	        cus.setCool(request.getParameter("cool"));
	        cus.setSsd(request.getParameter("ssd"));
	        cus.setEmail(request.getParameter("email"));
	        
		orderservice service =new orderservice();
		service.updateCustomer(cus);
		
		 RequestDispatcher dispatcher =request.getRequestDispatcher("readtable");
		
		dispatcher.forward(request, response);
	}

}
