package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		
		
		String username="root";
		String password="ABC123";
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/csp?characterEncoding=UTF-8", username,password);
		
		return con;

	}
}
