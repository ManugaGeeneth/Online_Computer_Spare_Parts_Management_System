package services;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.customer;
import utils.DBConnection;
public class Customerservice {

	public void regCustomer(customer cus) {
		try {
			
			String query = "insert into customer values('"+cus.getId()+"','"+cus.getName()+"','"+cus.getPrice()+"','"+cus.getQuantity()+"','"+cus.getOrderdate()+"','"+cus.getStatus()+"','"+cus.getRdate()+"','"+cus.getReason()+"')";
			Statement statement = DBConnection.getConnection().createStatement();
			statement.executeUpdate(query);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	} 
	public static List<customer> getById(String id){
		
			ArrayList<customer> customer = new ArrayList<customer>();
			
			try {
				
			String query = "select * from customer where id ";
			
			Statement statement = DBConnection.getConnection().createStatement();
			ResultSet rs = statement.executeQuery(query);
			while(rs.next()){
				customer cus = new customer();
				
				cus.setId(rs.getString("id"));
				cus.setName(rs.getString("name"));
				cus.setPrice(rs.getString("price"));
				cus.setQuantity(rs.getString("quantity"));
				cus.setOrderdate(rs.getString("orderdate"));
				cus.setStatus(rs.getString("status"));
				cus.setRdate(rs.getString("rdate"));
				cus.setReason(rs.getString("reason"));
				
				customer.add(cus);
			}
		}catch (Exception e) {
			e.printStackTrace();
			
		}
		return customer;	
	}
	public static List<customer> getAllCustomer(){
		ArrayList<customer> customers = new ArrayList<customer>();
		try {
			
			String query = "select * from customer";
			
			Statement statement = DBConnection.getConnection().createStatement();
			ResultSet rs = statement.executeQuery(query);
			while(rs.next()){
				customer cus = new customer();
				
				cus.setId(rs.getString("id"));
				cus.setName(rs.getString("name"));
				cus.setPrice(rs.getString("price"));
				cus.setQuantity(rs.getString("quantity"));
				cus.setOrderdate(rs.getString("orderdate"));
				cus.setStatus(rs.getString("status"));
				cus.setRdate(rs.getString("rdate"));
				cus.setReason(rs.getString("reason"));
				
				customers.add(cus);
			}
		}catch (Exception e) {
			e.printStackTrace();
			
		}
		return customers;
		
	}
	public void Updateorder(customer customer) {
		try {
			String query = "update customer SET name='"+customer.getName()+"',price='"+customer.getPrice()+"',quantity='"+customer.getQuantity()+"',orderdate='"+customer.getOrderdate()+"',status='"+customer.getStatus()+"',rdate='"+customer.getRdate()+"',reason='"+customer.getReason()+"'where id='"+customer.getId()+"'";
			
			Statement statement = DBConnection.getConnection().createStatement();
			statement.executeUpdate(query);
		}catch(Exception e) {
			e.printStackTrace();
			
		}
	}
	public void Deleteor(customer cus) {
		try {
			String query = "Delete From customer where id = '"+cus.getId()+"'";
			
			Statement statement = DBConnection.getConnection().createStatement();
			statement.executeUpdate(query);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	}

