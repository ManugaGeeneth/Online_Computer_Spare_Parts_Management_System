package services;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.order;
import utils.DBConnection;

public class orderservice {

    public void regcustomer(order cus) {
        try {
            // Updated SQL query to include backticks around 'order'
            String query = "INSERT INTO `order` (email, cpu, vcard, mem, mboard, cool, ssd) VALUES ('"
                    + cus.getEmail() + "', '"
                    + cus.getCpu() + "', '"
                    + cus.getVcard() + "', '"
                    + cus.getMem() + "', '"
                    + cus.getMboard() + "', '"
                    + cus.getCool() + "', '"
                    + cus.getSsd() + "')";
            
            Statement statement = DBConnection.getConnection().createStatement();
            statement.executeUpdate(query);
                    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // Display all customers
    public ArrayList<order> getAllCustomer() {
        ArrayList<order> listcus = new ArrayList<>();
        try {
            // Updated SQL query to include backticks around 'order'
            String query = "SELECT * FROM `order`";
            Statement statement = DBConnection.getConnection().createStatement();
            ResultSet rs = statement.executeQuery(query);
            
            while (rs.next()) {
                order cus = new order();
                cus.setEmail(rs.getString("email"));
                cus.setCpu(rs.getString("cpu"));
                cus.setVcard(rs.getString("vcard"));
                cus.setMem(rs.getString("mem"));
                cus.setMboard(rs.getString("mboard"));
                cus.setCool(rs.getString("cool"));
                cus.setSsd(rs.getString("ssd"));
                
                listcus.add(cus);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return listcus;
    }

    // Update customer data
    public void updateCustomer(order order) {
        try {
            // Updated SQL query to include backticks around 'order'
            String query = "UPDATE `order` SET "
                + "cpu = '" + order.getCpu() + "', "
                + "vcard = '" + order.getVcard() + "', "
                + "mem = '" + order.getMem() + "', "
                + "mboard = '" + order.getMboard() + "', "
                + "cool = '" + order.getCool() + "', "
                + "ssd = '" + order.getSsd() + "' "
                + "WHERE email = '" + order.getEmail() + "'";

            Statement statement = DBConnection.getConnection().createStatement();
            statement.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete customer
    public void deleteCustomer(order cus) {
        try {
            // Updated SQL query to include backticks around 'order'
            String query = "DELETE FROM `order` WHERE email = '" + cus.getEmail() + "'";
            Statement statement = DBConnection.getConnection().createStatement();
            statement.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
